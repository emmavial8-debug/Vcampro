package io.twinkle.unreal.util;

public class ModuleStatus {
    public static boolean isActivated() {
        return false;
    }
}
